module.exports = require('./lib/sqlite3');
